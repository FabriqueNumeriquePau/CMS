<?php
$sql1 = "select 1 from ". _DB_PREFIX_ ."easy_newsletter where email = '" . pSQL($email) . "';";
$sql2 = "INSERT INTO ". _DB_PREFIX_ ."easy_newsletter (email) values ('" . pSQL($email) . "');";
if (Db::getInstance()->getValue($sql1) != 1) {
    Db::getInstance()->execute($sql2);
}
