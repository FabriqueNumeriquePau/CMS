<?php
$sql = "select email from ". _DB_PREFIX_ ."easy_newsletter;";
$categoriesArray = (Db::getInstance())->executeS($sql, true);
